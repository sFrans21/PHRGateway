﻿namespace APIWHD.Models
{
    public class MFAValidationRequestModel
    {
        public string Otp { get; set; }
        public string SessionId { get; set; }

       
    }
}
