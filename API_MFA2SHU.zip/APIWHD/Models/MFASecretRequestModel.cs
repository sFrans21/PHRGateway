﻿namespace APIWHD.Models
{
    public class MFASecretRequestModel
    {
        public string MFAAccount { get; set; }

        public string MFAIssuer { get; set; }
    }
}
