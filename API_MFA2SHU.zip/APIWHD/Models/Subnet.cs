﻿namespace APIWHD.Models
{
    public class Subnet
    {
        public string SubnetName { get; set; }
        public string IPAddress { get; set; }
        public string SubnetMask { get; set; }
        public string Description { get; set; }
    }
}
