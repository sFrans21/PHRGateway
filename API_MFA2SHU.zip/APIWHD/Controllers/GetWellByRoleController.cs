﻿using APIWHD.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIWHD.Models;
using Microsoft.EntityFrameworkCore;


namespace APIWHD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetWellByRoleController : ControllerBase
    {       
        //public readonly LoginViewModel _loginViewModel;
        public readonly APIDBContext _context;

        public GetWellByRoleController(APIDBContext context)
        {
            _context = context;
        }

        //public string AddFilter()
        //{
        //    string username = _userService.GetCurrentUserName();
        //    //string username = _loginViewModel.Username;
        //    //string username = "mk.mayodhi.muhammad"; // Hardcoded username
        //    return username;
        //}

        // api/GetWellByRole
        [HttpGet]
        //[Route("Get")]
        public async Task<List<VwGetWellByRole>> Get()
        {
            return await _context.VwGetWellByRole.ToListAsync();
        }

        // api/GetWellByRole/Get/username
        [HttpGet]
        //[Route("Get")]
        [Route("{userid}")]
        //public async Task<List<VwGetWellByRole>> Getwell(string userid)
        public async Task<IActionResult> Getwell(string userid)

        {
            //string username = AddFilter();
            //userid = username;

            //return await _context.VwGetWellByRole.ToListAsync();
            //return await _context.VwGetWellByRole.Where(a => a.User_Name == username).ToListAsync();
            int count = await _context.VwGetWellByRole.Where(a => a.User_Name == userid).CountAsync(); // count total list
            var response = await _context.VwGetWellByRole.Where(a => a.User_Name == userid).ToListAsync();
            if (response.Count == 0)
            {
                return NotFound($"Tidak ada data");
            }
            return Ok(response);
        }

        // api/GetWellByRole/count
        //[HttpGet]
        //[Route("count/{userid}")]
        //public async Task<int> CountData(string userid)
        //{
        //    //string username = AddFilter();
        //    //userid = username;

        //    int count = await _context.VwGetWellByRole
        //        .Where(a => a.User_Name == userid)
        //        .CountAsync();

        //    return count;
        //}
    }
}
