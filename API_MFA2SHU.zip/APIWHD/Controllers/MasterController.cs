﻿using APIWHD.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using System.Net.Http;
using System.Net.Http.Headers;

namespace APIWHD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterController : ControllerBase
    {
        private readonly APIDBContext _context;
        private readonly ITransactionDashboardService _services;
        private readonly IMemoryCache _memoryCache;
        private readonly IHttpClientFactory _httpClientFactory;

        public MasterController(APIDBContext context, ITransactionDashboardService services, IMemoryCache memoryCache, IHttpClientFactory httpClientFactory)
        {
            _context = context;
            _services = services;
            _memoryCache = memoryCache;
            _httpClientFactory = httpClientFactory;
        }

        [HttpGet]
        [Route("Role")]
        public async Task<IActionResult> GetRole()
        {
            var result = await _context.Whd_Role.ToListAsync();
            return Ok(result);
        }

        //Get Role using TOKEN from SSOLOGIN
        [HttpGet]
        [Route("RoleAuth")]
        public async Task<IActionResult> GetRoleAuth()
        {
            // Retrieve the access token from cache
            if (_memoryCache.TryGetValue("AccessToken", out string accessToken))
            {
                // Use the access token in your API call
                var client = _httpClientFactory.CreateClient();
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                var result = await _context.Whd_Role.ToListAsync();
                return Ok(result);
            }
            else
            {
                // Handle the case where the access token is not available
                return BadRequest("Access token not found.");
            }
        }

        [HttpGet]
        [Route("Role/{username}")]
        public async Task<IActionResult> GetRolebyUser(string username)
        {
            var result = await _services.GetUserRole(username);
            if (result.Count == 0)
            {
                return NotFound($"Tidak ada Role untuk username {username}");
            }
            return Ok(result);
        }

        [HttpGet("Field")]
        public async Task<IActionResult> GetField()
        {
            var result = await _context.Whd_Field.ToListAsync();
            return Ok(result);
        }

        [HttpGet("Type")]
        public async Task<IActionResult> Gettype()
        {
            var result = await _context.Whd_Type.ToListAsync();
            return Ok(result);
        }

        [HttpGet("UserRole")]
        public async Task<IActionResult> GetUser()
        {
            var result = await _context.Whd_Users.ToListAsync();
            return Ok(result);
        }

    }
}
