﻿using APIWHD.Data;
using APIWHD.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIWHD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WhdActivityController : ControllerBase
    {
        private readonly APIDBContext _context;

        public WhdActivityController(APIDBContext context)
        {
            _context = context;
        }

        // api/WhdActivity
        [HttpGet]
        public async Task<IActionResult> GetActivity()
        {
            var result = await _context.Whd_Activity.ToListAsync();
            if (result.Count == 0)
            {
                return BadRequest($"No Activity");
            }
            return Ok(result);
        }
    }
}
