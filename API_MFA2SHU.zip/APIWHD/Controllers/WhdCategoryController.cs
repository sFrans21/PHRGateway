﻿using APIWHD.Data;
using APIWHD.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIWHD.Controllers
{
    //api/WhdCategory/
    [Route("api/[controller]")]
    [ApiController]
    public class WhdCategoryController : ControllerBase
    {
        public readonly APIDBContext _context;

        public WhdCategoryController(APIDBContext context)
        {
            _context = context;
        }

        // Get Category All
        // api/WhdCategory/GetCategoryAll
        [HttpGet]
        [Route("GetCategoryAll")]
        public async Task<List<Whd_Category>> GetCategoryAll()
        {
            return await _context.Whd_Category.ToListAsync();
        }

        // Get Category by CategoryDesc clue
        [HttpGet]
        [Route("GetCategorybyCategoryClue/{categorydesc}")]
        public List<Whd_Category> GetCategorybyCategoryClue(string categorydesc)
        {
            return _context.Whd_Category.Where(a => EF.Functions.Like(a.CategoryDesc, $"%{categorydesc}%")).ToList();
        }
    }
}
