﻿using APIWHD.Data;
using APIWHD.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIWHD.Controllers
{
    //api/GetWell/
    [Route("api/[controller]")]
    [ApiController]
    public class GetWellController : ControllerBase
    {
        //private readonly MemoryCache _cache;
        public readonly APIDBContext _context;

        public GetWellController(APIDBContext context)
        {
            _context = context;
        }

        // api/GetWell/GetWellAll
        [HttpGet]
        [Route("GetWellAll")]
        public async Task<List<VwWellForDDL2>> GetWellAll()
        {
            return await _context.VwWellForDDL2.ToListAsync();
        }

        // api/GetbyName/{search}
        [HttpGet]
        [Route("GetbyName/{search}")]
        public async Task<List<VwWellForDDL2>> GetbyName(string search)
        {
            return await _context.VwWellForDDL2.Where(a => EF.Functions.Like(a.WellName, $"%{search}%") || EF.Functions.Like(a.WELL, $"%{search}%")).ToListAsync();
            //return await _context.VwWellForDDL2.ToListAsync();
        }

    }
}
