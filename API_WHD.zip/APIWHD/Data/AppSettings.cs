﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIWHD.Data
{
    public class AppSettings
    {
        public string ImgTempFolderPath { get; set; }
        public string ImgUploadFolderPath { get; set; }
    }
}
